# SVD Error Report

- status: not_computed
- reason: requires conversion run with original and compressed factors
