# Baseline Adapter Inventory

```json
{
  "timestamp_utc": "2026-05-03T16:05:11.556774Z",
  "model_path": "/kaggle/input/models/metric/nemotron-3-nano-30b-a3b-bf16/transformers/default/1",
  "adapter_path": "/kaggle/input/models/huikang/nemotron-adapter/transformers/default/20",
  "baseline_submission_path": "/kaggle/working/submission.zip",
  "baseline_inventory": {
    "adapter_config": {
      "alpha_pattern": {},
      "auto_mapping": null,
      "base_model_name_or_path": null,
      "bias": "none",
      "corda_config": null,
      "eva_config": null,
      "exclude_modules": null,
      "fan_in_fan_out": false,
      "inference_mode": false,
      "init_lora_weights": true,
      "layer_replication": null,
      "layers_pattern": null,
      "layers_to_transform": null,
      "loftq_config": {},
      "lora_alpha": 32,
      "lora_bias": false,
      "lora_dropout": 0,
      "megatron_config": null,
      "megatron_core": "megatron.core",
      "modules_to_save": null,
      "peft_type": "LORA",
      "r": 32,
      "rank_pattern": {},
      "revision": null,
      "target_modules": "all-linear",
      "task_type": "CAUSAL_LM",
      "trainable_token_indices": null,
      "use_dora": false,
      "use_rslora": false
    },
    "target_modules": "all-linear",
    "lora_alpha": 32,
    "r": 32,
    "inference_mode": false,
    "tensor_key_count": 418,
    "module_tensor_count": {
      "gate_proj": 46,
      "out_proj": 46,
      "x_proj": 46,
      "other": 138,
      "down_proj": 46,
      "up_proj": 46,
      "k_proj": 12,
      "o_proj": 12,
      "q_proj": 12,
      "v_proj": 12,
      "lm_head": 2
    },
    "rank_distribution": {
      "32": 140
    },
    "max_rank": 32,
    "rank_violations": [],
    "zero_shape_tensors": [
      {
        "key": "base_model.model.model.layers.1.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.1.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.10.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.10.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.13.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.13.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.15.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.15.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.17.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.17.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.20.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.20.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.22.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.22.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.24.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.24.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.27.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.27.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.29.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.29.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.3.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.3.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.31.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.31.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.34.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.34.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.36.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.36.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.38.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.38.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.40.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.40.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.43.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.43.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.45.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.45.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.47.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.47.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.49.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.49.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.51.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.51.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.6.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.6.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.8.mixer.experts.w3.lora_A.weight",
        "shape": [
          0
        ]
      },
      {
        "key": "base_model.model.model.layers.8.mixer.experts.w3.lora_B.weight",
        "shape": [
          0
        ]
      }
    ],
    "unexpected_keys": [
      "base_model.model.model.layers.0.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.0.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.0.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.0.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.1.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.1.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.1.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.1.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.1.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.1.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.10.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.10.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.10.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.10.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.10.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.10.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.11.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.11.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.11.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.11.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.13.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.13.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.13.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.13.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.13.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.13.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.14.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.14.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.14.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.14.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.15.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.15.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.15.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.15.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.15.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.15.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.16.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.16.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.16.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.16.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.17.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.17.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.17.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.17.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.17.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.17.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.18.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.18.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.18.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.18.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.2.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.2.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.2.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.2.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.20.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.20.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.20.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.20.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.20.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.20.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.21.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.21.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.21.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.21.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.22.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.22.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.22.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.22.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.22.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.22.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.23.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.23.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.23.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.23.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.24.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.24.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.24.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.24.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.24.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.24.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.25.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.25.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.25.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.25.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.27.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.27.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.27.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.27.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.27.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.27.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.28.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.28.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.28.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.28.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.29.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.29.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.29.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.29.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.29.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.29.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.3.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.3.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.3.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.3.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.3.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.3.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.30.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.30.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.30.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.30.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.31.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.31.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.31.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.31.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.31.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.31.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.32.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.32.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.32.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.32.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.34.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.34.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.34.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.34.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.34.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.34.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.35.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.35.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.35.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.35.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.36.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.36.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.36.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.36.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.36.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.36.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.37.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.37.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.37.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.37.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.38.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.38.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.38.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.38.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.38.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.38.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.39.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.39.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.39.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.39.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.4.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.4.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.4.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.4.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.40.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.40.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.40.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.40.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.40.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.40.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.41.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.41.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.41.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.41.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.43.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.43.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.43.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.43.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.43.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.43.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.44.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.44.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.44.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.44.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.45.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.45.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.45.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.45.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.45.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.45.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.46.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.46.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.46.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.46.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.47.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.47.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.47.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.47.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.47.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.47.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.48.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.48.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.48.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.48.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.49.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.49.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.49.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.49.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.49.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.49.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.50.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.50.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.50.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.50.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.51.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.51.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.51.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.51.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.51.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.51.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.6.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.6.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.6.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.6.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.6.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.6.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.7.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.7.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.7.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.7.mixer.x_proj.lora_B.weight",
      "base_model.model.model.layers.8.mixer.experts.w1.lora_A.weight",
      "base_model.model.model.layers.8.mixer.experts.w1.lora_B.weight",
      "base_model.model.model.layers.8.mixer.experts.w2.lora_A.weight",
      "base_model.model.model.layers.8.mixer.experts.w2.lora_B.weight",
      "base_model.model.model.layers.8.mixer.experts.w3.lora_A.weight",
      "base_model.model.model.layers.8.mixer.experts.w3.lora_B.weight",
      "base_model.model.model.layers.9.mixer.gate_proj.lora_A.weight",
      "base_model.model.model.layers.9.mixer.gate_proj.lora_B.weight",
      "base_model.model.model.layers.9.mixer.x_proj.lora_A.weight",
      "base_model.model.model.layers.9.mixer.x_proj.lora_B.weight"
    ],
    "missing_expected_modules": [
      "in_proj"
    ],
    "prefix_check": {
      "contains_backbone": false,
      "contains_model_model": true
    },
    "adapter_model_size_bytes": 1544348352,
    "adapter_model_sha256": "179202c3305332f080e7f3cef17268b08250773b48e6cc73b5e8c0d424be88b8"
  },
  "zip_inventory": {
    "exists": false
  },
  "conversion_stage_log": [
    {
      "stage": "raw adapter load",
      "status": "not_executed_in_this_environment",
      "notes": "instrumentation scaffold only"
    },
    {
      "stage": "prefix rename",
      "status": "not_executed_in_this_environment",
      "notes": "instrumentation scaffold only"
    },
    {
      "stage": "expert unfuse",
      "status": "not_executed_in_this_environment",
      "notes": "instrumentation scaffold only"
    },
    {
      "stage": "Mamba gate/x merge",
      "status": "not_executed_in_this_environment",
      "notes": "instrumentation scaffold only"
    },
    {
      "stage": "SVD compression",
      "status": "not_executed_in_this_environment",
      "notes": "instrumentation scaffold only"
    },
    {
      "stage": "target_modules reconciliation",
      "status": "not_executed_in_this_environment",
      "notes": "instrumentation scaffold only"
    },
    {
      "stage": "adapter_config rewrite",
      "status": "not_executed_in_this_environment",
      "notes": "instrumentation scaffold only"
    },
    {
      "stage": "final safetensors export",
      "status": "not_executed_in_this_environment",
      "notes": "instrumentation scaffold only"
    },
    {
      "stage": "submission.zip export",
      "status": "not_executed_in_this_environment",
      "notes": "instrumentation scaffold only"
    }
  ],
  "svd_error_report": {
    "status": "not_computed",
    "reason": "requires conversion run with original and compressed factors"
  }
}
```
