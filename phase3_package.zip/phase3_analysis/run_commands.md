# Phase3 Run Commands

## Commands executed

```bash
python phase3_make_recommendation.py --output-dir phase3_analysis
```

Actual command line captured by script:

```bash
/usr/local/lib/python3.12/dist-packages/colab_kernel_launcher.py -f /tmp/tmpieswi9_f.json --HistoryManager.hist_file=:memory:
```

## Inputs

- Golden notebook/script: `b3-nemotron-svd-26042701.ipynb`
- Adapter path: `/kaggle/input/models/huikang/nemotron-adapter/transformers/default/20`
- Validation path: `/kaggle/working/phase3_validation_split.csv`
- Prediction path: `NOT_PROVIDED`
- Logprob path: `NOT_PROVIDED`

## Repro settings

- Seed: `NOT_PROVIDED`
- Generation config: `Golden Baseline unchanged; not executed by this notebook`
- Script version: `phase3_make_recommendation.py stdlib-v1`
- Git hash: `NOT_AVAILABLE`
- Execution datetime UTC: `2026-06-06T08:04:27.458729+00:00`

## Generated artifacts

- `phase3_analysis/category_failure_summary.csv`
- `phase3_analysis/category_map.csv`
- `phase3_analysis/failure_cases_bit_manipulation.csv`
- `phase3_analysis/failure_cases_cryptarithm.csv`
- `phase3_analysis/failure_cases_numeral_conversion.csv`
- `phase3_analysis/failure_type_summary.csv`
- `phase3_analysis/golden_validation_predictions.jsonl`
- `phase3_analysis/golden_validation_summary.csv`
- `phase3_analysis/min_logprob_summary.csv`
- `phase3_analysis/validation_set_labeled.csv`
