# Phase3 Run Commands

## Commands executed

```bash
python phase3_make_recommendation.py --output-dir phase3_analysis
```

Actual command line captured by script:

```bash
/usr/local/lib/python3.12/dist-packages/colab_kernel_launcher.py -f /tmp/tmpvdkmri74.json --HistoryManager.hist_file=:memory:
```

## Inputs

- Golden notebook/script: `b3-nemotron-svd-26042701.ipynb`
- Adapter path: `/kaggle/input/models/huikang/nemotron-adapter/transformers/default/20`
- Validation path: `NOT_PROVIDED`
- Prediction path: `NOT_PROVIDED`
- Logprob path: `NOT_PROVIDED`

## Repro settings

- Seed: `42`
- Generation config: `Golden Baseline unchanged; analysis-only notebook; no generation executed unless prediction/logprob inputs were created separately`
- Script version: `phase3_make_recommendation.py stdlib-v1`
- Git hash: `NOT_AVAILABLE`
- Execution datetime UTC: `2026-06-06T09:04:16.803490+00:00`

## Generated artifacts

- `phase3_analysis/category_failure_summary.csv`
- `phase3_analysis/category_map.csv`
- `phase3_analysis/failure_cases_bit_manipulation.csv`
- `phase3_analysis/failure_cases_cryptarithm.csv`
- `phase3_analysis/failure_cases_numeral_conversion.csv`
- `phase3_analysis/failure_type_summary.csv`
- `phase3_analysis/golden_validation_predictions.jsonl`
- `phase3_analysis/golden_validation_summary.csv`
- `phase3_analysis/min_logprob_summary.csv`
- `phase3_analysis/validation_set_labeled.csv`
